package controller;

import org.junit.Test;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.io.StringReader;

import model.IImageStorer;
import model.Image;
import model.ImageProcessingModel;
import model.MockImageStorer;
import view.ImageProcessingView;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Tests for the ControllerImpl, which takes in input from a Readable and mutates the model.
 */
public class ImageProcessingControllerTest {


  Reader in;
  Appendable log = new StringBuilder();
  Image image = new ImageProcessingModel("small", 2, 2, 255);


  IImageStorer mockModel = new MockImageStorer(log, image);
  ImageProcessingView view = new ImageProcessingView(image, System.out);
  ImageProcessorController controller;

  @Test
  public void controllerToModel() {
    image.setPixel(0, 0, 50, 50, 50);
    image.setPixel(0, 1, 50, 50, 50);
    image.setPixel(1, 1, 50, 50, 50);
    image.setPixel(1, 0, 50, 50, 50);

    in = new StringReader("brighten 10 small small-brighter");
    controller = new ControllerImpl(mockModel, view, in);

    controller.control();
    assertEquals("small-brighter\n"
            +
            "P3\n"
            +
            "2 2\n"
            +
            "255\n"
            +
            "60 60 60 "
            +
            "60 60 60 \n"
            +
            "60 60 60 "
            +
            "60 60 60 \n", log.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void controllerTooManyArgs() {

    in = new StringReader("brighten 10 mack mack mack");
    controller = new ControllerImpl(in);
    controller.control();

  }

  @Test(expected = IllegalArgumentException.class)
  public void controllerTooFewArgs() {
    in = new StringReader("luma koala");
    controller = new ControllerImpl(in);
    controller.control();
  }

  @Test
  public void controllerTestSave() {
    in = new StringReader("load images/Koala.ppm mackpicture");
    controller = new ControllerImpl(in);
    controller.control();
    in = new StringReader("brighten 10 mackpicture mack-picture-edited");
    controller.control();
    in = new StringReader("save images/mackpicture.ppm mack-picture-edited");
    controller.control();
    assertTrue(in.toString().equals("save"));
    //if there is an error with save it will throw a FileNotFoundException.
  }

  @Test
  public void testExportPNG() {
    in = new StringReader("load images/Koala.ppm koala save images/Koala.png koala");
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }

  @Test
  public void testExportJPG() {
    in = new StringReader("load images/Koala.ppm koala save images/Koala.jpg koala");
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }

  @Test
  public void testImportPNG() {
    in = new StringReader("load images/koala-horizontal.png koala save images/Koala.jpg koala");
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }

  @Test
  public void testImportJPG() {
    in = new StringReader("load images/koala-horizontal.jpg koala save images/Koala.jpg koala");
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }

  @Test
  public void testScript() {
    try {
      in = new FileReader("res/script.txt");
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("file not found");
    }
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testScriptNoFile() {
    try {
      in = new FileReader("usemee.txt");
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("file not found");
    }
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }

  @Test(expected = IllegalArgumentException.class)
  public void testBadScript() {
    try {
      in = new FileReader("usemebad.txt");
    } catch (FileNotFoundException e) {
      throw new IllegalArgumentException("file not found");
    }
    controller = new ControllerImpl(mockModel, view, in);
    controller.control();
    assertEquals("", log.toString());
  }
}
