package view;

import model.Image;
import model.ImageProcessingModel;

import static org.junit.Assert.assertEquals;

/**
 * test class for ImageProcessingView.
 */
public class ImageProcessingViewTest {

  Image image = new ImageProcessingModel("Test", 2, 2, 255);
  Appendable sb = new StringBuilder();
  IView view = new ImageProcessingView(image, sb);

  @org.junit.Test
  public void makePPM() {
    image.setPixel(0, 0, 0, 255, 0);
    image.setPixel(0, 1, 0, 255, 0);
    image.setPixel(1, 0, 0, 255, 0);
    image.setPixel(1, 1, 0, 255, 0);

    assertEquals("P3\n"
            +
            "2 2\n"
            +
            "255\n"
            +
            "0 255 0 0 255 0 \n"
            +
            "0 255 0 0 255 0 ", view.makePPM());
  }
}