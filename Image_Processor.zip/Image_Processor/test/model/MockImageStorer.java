package model;

import java.util.Map;

import view.Utils;

/**
 * Mock model for controller tests.
 */
public class MockImageStorer implements IImageStorer {
  Appendable out;
  Image image;

  /**
   * Mock stores controller input in the appendable.
   */
  public MockImageStorer(Appendable out, Image image) {
    this.out = out;
    this.image = image;
  }

  @Override
  public void addImage(String name, Image image) {

    try {
      out.append(name).append("\n");
    } catch (Exception e) {
      e.printStackTrace();
    }

  }

  @Override
  public Image getImage(String name) {
    return this.image;
  }

  @Override
  public void clearImages() {
    Utils.write("clear", out);
  }

  @Override
  public Map<String, Image> getImages() {
    return null;
  }
}
