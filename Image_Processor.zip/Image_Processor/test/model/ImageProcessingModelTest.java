package model;

import org.junit.Test;

import strategies.BlueComponent;
import strategies.Blur;
import strategies.Brighten;
import strategies.GreenComponent;
import strategies.Greyscale;
import strategies.HorizontalFlip;
import strategies.IStrategy;
import strategies.IStrategy3Args;
import strategies.Intensity;
import strategies.Luma;
import strategies.RedComponent;
import strategies.Sepia;
import strategies.Sharpen;
import strategies.Value;
import strategies.VerticalFlip;

import static org.junit.Assert.assertEquals;

/**
 * test class for ImageProcessingModel. Tests strategies, constructor exceptions, get/set methods.
 */
public class ImageProcessingModelTest {
  Image image;

  IStrategy strategy;
  IStrategy3Args strategy3Args;

  @Test
  public void testVerticalStrategy() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 0, 255, 0);
    image.setPixel(0, 1, 0, 255, 0);
    image.setPixel(1, 0, 0, 0, 255);
    image.setPixel(1, 1, 0, 0, 255);
    strategy = new VerticalFlip();
    Image verticalImage = strategy.adjustImage(image, "vertical-test");
    assertEquals(image.getPixelAt(0, 0), verticalImage.getPixelAt(0, 1));
  }

  @Test
  public void testHorizontalStrategy() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 0, 255, 0);
    image.setPixel(0, 1, 0, 255, 0);
    image.setPixel(1, 0, 0, 0, 255);
    image.setPixel(1, 1, 0, 0, 255);
    strategy = new HorizontalFlip();
    Image horizontalImage = strategy.adjustImage(image, "horizontal-test");
    assertEquals(image.getPixelAt(0, 0), horizontalImage.getPixelAt(1, 0));
  }

  @Test
  public void brightenTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 0, 200, 0);
    image.setPixel(0, 1, 0, 200, 0);
    image.setPixel(1, 0, 0, 0, 200);
    image.setPixel(1, 1, 0, 0, 200);
    strategy3Args = new Brighten();
    Image adjustedImage = strategy3Args.adjustImage("55", image, "bright");

    assertEquals(255, adjustedImage.getPixelAt(0, 1).getG());
  }

  @Test
  public void darkenTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 0, 200, 0);
    image.setPixel(0, 1, 0, 200, 0);
    image.setPixel(1, 0, 0, 0, 200);
    image.setPixel(1, 1, 0, 0, 200);
    strategy3Args = new Brighten();
    Image adjustedImage = strategy3Args.adjustImage("-50", image, "bright");

    assertEquals(150, adjustedImage.getPixelAt(0, 1).getG());
  }

  @Test
  public void redComponentTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 200, 200, 200);
    image.setPixel(0, 1, 200, 200, 200);
    image.setPixel(1, 0, 200, 200, 200);
    image.setPixel(1, 1, 200, 200, 200);
    strategy = new RedComponent();
    Image adjustedImage = strategy.adjustImage(image, "red-component");

    assertEquals(0, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(200, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(200, adjustedImage.getPixelAt(0, 1).getB());

  }

  @Test
  public void greenComponentTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 200, 200, 200);
    image.setPixel(0, 1, 200, 200, 200);
    image.setPixel(1, 0, 200, 200, 200);
    image.setPixel(1, 1, 200, 200, 200);
    strategy = new GreenComponent();
    Image adjustedImage = strategy.adjustImage(image, "green-component");

    assertEquals(200, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(0, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(200, adjustedImage.getPixelAt(0, 1).getB());

  }

  @Test
  public void blueComponentTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 200, 200, 200);
    image.setPixel(0, 1, 200, 200, 200);
    image.setPixel(1, 0, 200, 200, 200);
    image.setPixel(1, 1, 200, 200, 200);
    strategy = new BlueComponent();
    Image adjustedImage = strategy.adjustImage(image, "blue-component");

    assertEquals(200, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(200, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(0, adjustedImage.getPixelAt(0, 1).getB());

  }

  @Test
  public void intensityTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Intensity();
    Image adjustedImage = strategy.adjustImage(image, "intensity");

    assertEquals(150, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(150, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(150, adjustedImage.getPixelAt(0, 1).getB());
  }

  @Test
  public void lumaTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Luma();
    Image adjustedImage = strategy.adjustImage(image, "luma");

    assertEquals(143, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(143, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(143, adjustedImage.getPixelAt(0, 1).getB());
  }

  @Test
  public void valueTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Value();
    Image adjustedImage = strategy.adjustImage(image, "value");

    assertEquals(255, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(255, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(255, adjustedImage.getPixelAt(0, 1).getB());
  }

  @Test
  public void sepiaTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Sepia();
    Image adjustedImage = strategy.adjustImage(image, "sepia");

    assertEquals(192, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(172, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(133, adjustedImage.getPixelAt(0, 1).getB());
  }

  @Test
  public void greyscaleTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Greyscale();
    Image adjustedImage = strategy.adjustImage(image, "greyscale");

    assertEquals(142, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(142, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(142, adjustedImage.getPixelAt(0, 1).getB());
  }

  @Test
  public void blurTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Blur();
    Image adjustedImage = strategy.adjustImage(image, "blur");

    assertEquals(51, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(70, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(89, adjustedImage.getPixelAt(0, 1).getB());
  }

  @Test
  public void sharpenTest() {
    image = new ImageProcessingModel("Test", 2, 2, 255);
    image.setPixel(0, 0, 150, 200, 250);
    image.setPixel(0, 1, 100, 150, 200);
    image.setPixel(1, 0, 30, 35, 40);
    image.setPixel(1, 1, 40, 41, 42);
    strategy = new Sharpen();
    Image adjustedImage = strategy.adjustImage(image, "sharpen");

    assertEquals(156, adjustedImage.getPixelAt(0, 1).getR());
    assertEquals(219, adjustedImage.getPixelAt(0, 1).getG());
    assertEquals(255, adjustedImage.getPixelAt(0, 1).getB());
  }


  @Test(expected = IllegalArgumentException.class)
  public void testNullName() {
    image = new ImageProcessingModel(null, 2, 2, 233);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidHeight() {
    image = new ImageProcessingModel("Test", 1, -2, 233);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidWidth() {
    image = new ImageProcessingModel("Test", -1, 2, 233);
  }

  @Test(expected = IllegalArgumentException.class)
  public void testInvalidMaxValue() {
    image = new ImageProcessingModel("Test", 1, 2, -233);
  }

  @Test
  public void testSuccessfulConstructor() {
    image = new ImageProcessingModel("Success", 2, 2, 255);
    assertEquals(2, image.getHeight());
  }



}