package model;

import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * Tests confirming the image storer saves and retrieves images properly.
 */
public class ImageStorerTest {
  Image image = new ImageProcessingModel("test", 2, 2, 255);
  IImageStorer storer = new ImageStorer();

  @Before
  public void setUpImage() {
    image.setPixel(0, 0, 255, 0, 0);
    image.setPixel(0, 1, 255, 0, 0);
    image.setPixel(1, 0, 0, 0, 255);
    image.setPixel(1, 1, 0, 0, 255);


  }

  @Test
  public void addImage() {
    storer.addImage("test", image);
    Image newImage = new ImageProcessingModel("test", 2, 2, 255);
    newImage.setPixel(0, 0, 255, 0, 0);
    newImage.setPixel(0, 1, 255, 0, 0);
    newImage.setPixel(1, 0, 0, 0, 255);
    newImage.setPixel(1, 1, 0, 0, 255);
    assertEquals(newImage, storer.getImage("test"));
  }

  @Test
  public void getImage() {
    storer.addImage("test", image);
    Image newImage = new ImageProcessingModel("test", 2, 2, 255);
    newImage.setPixel(0, 0, 255, 0, 0);
    newImage.setPixel(0, 1, 255, 0, 0);
    newImage.setPixel(1, 0, 0, 0, 255);
    newImage.setPixel(1, 1, 0, 0, 255);
    assertEquals(newImage, storer.getImage("test"));
  }

  @Test
  public void clearImages() {
    storer.addImage("test", image);
    Image newImage = new ImageProcessingModel("test", 2, 2, 255);
    newImage.setPixel(0, 0, 255, 0, 0);
    newImage.setPixel(0, 1, 255, 0, 0);
    newImage.setPixel(1, 0, 0, 0, 255);
    newImage.setPixel(1, 1, 0, 0, 255);
    storer.clearImages();
    assertEquals(0, storer.getImages().size());
  }
}