package model;

import org.junit.Before;
import org.junit.Test;

import strategies.HorizontalFlip;
import strategies.IStrategy;
import strategies.VerticalFlip;

import static org.junit.Assert.assertEquals;

/**
 * Tests to check the correct images are output when multiple functions are applied to images.
 */
public class CompoundedStrategiesTest {
  IStrategy strategy;
  Image image;
  Image verticalVertical;

  Image horizontalHorizontal;

  @Before
  public void setUp() {
    image = new ImageProcessingModel("test", 2, 2, 255);
    image.setPixel(0, 0, 0, 255, 0);
    image.setPixel(0, 1, 0, 255, 0);
    image.setPixel(1, 0, 0, 0, 255);
    image.setPixel(1, 1, 0, 0, 255);
  }

  @Test
  public void testVerticalVerticalSame() {
    Image vertical = new VerticalFlip().adjustImage(image, "vertical");
    verticalVertical = new VerticalFlip().adjustImage(vertical,
            "vertical-vertical");

    assertEquals(image, verticalVertical);
  }

  @Test
  public void testHorizontalHorizontalSame() {
    Image horizontal = new HorizontalFlip().adjustImage(image, "horizontal");
    horizontalHorizontal = new HorizontalFlip().adjustImage(image, "horizontal-horizontal");

    assertEquals(image, horizontalHorizontal);
  }





}
