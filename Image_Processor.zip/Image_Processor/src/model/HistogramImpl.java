package model;

/**
 * Represents a Histogram of an image.
 */
public class HistogramImpl implements Histogram {


  private int[] redVals;

  private int[] greenVals;

  private int[] blueVals;

  private int[] intensityVals;


  /**
   * Constructs four histograms from an image. One for each of its red, green, blue, and intensity
   * values for each pixel.
   *
   * @param image the image the histograms will be made from.
   */
  public HistogramImpl(Image image) {
    int width = image.getWidth();
    int height = image.getMaxValue();
    this.redVals = new int[image.getWidth() * image.getHeight()];
    this.greenVals = new int[image.getWidth() * image.getHeight()];
    this.blueVals = new int[image.getWidth() * image.getHeight()];
    this.intensityVals = new int[image.getWidth() * image.getHeight()];

    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        redVals[j + i * width] = image.getPixelAt(j, i).getR();
      }
    }
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        greenVals[j + i * width] = image.getPixelAt(j, i).getG();
      }
    }
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        blueVals[j + i * width] = image.getPixelAt(j, i).getB();
      }
    }
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        intensityVals[j + i * width] = (int) Math.round(image.getPixelAt(j, i).getG() +
                image.getPixelAt(j, i).getR() + image.getPixelAt(j, i).getB() / 3.0);
      }
    }
  }


  @Override
  public int[] getRedVals() {

    return redVals;
  }

  @Override
  public int[] getGreenVals() {

    return greenVals;
  }

  @Override
  public int[] getBlueVals() {

    return blueVals;
  }

  @Override
  public int[] getIntensityVals() {


    return intensityVals;
  }


}
