package model;

import java.util.Objects;

/**
 * class Pixel represents a pixel and all of its dimensions.
 */
public class Pixel implements IPixel {
  private final int xPos;
  private final int yPos;
  private final int r;
  private final int g;
  private final int b;
  private final int maxValue;

  /**
   * constructor for Pixel that initializes all of its fields.
   *
   * @param xPos     the x position of the pixel.
   * @param yPos     the y position of the pixel.
   * @param r        the r value of the pixel.
   * @param g        the g value of the pixel.
   * @param b        the b value of the pixel.
   * @param maxValue the color max value of the pixel.
   */
  Pixel(int xPos, int yPos, int r, int g, int b, int maxValue) {
    if (xPos < 0 || yPos < 0) {
      throw new IllegalArgumentException("Cannot have negative x or y position.");
    }
    if (r < 0 || r > maxValue || g < 0 || g > maxValue || b < 0 || b > maxValue) {
      throw new IllegalArgumentException("Invalid r, g, or b value");
      //need to set these to zero if this is reached so that darkening image works.
    }
    if (maxValue < 1) {
      throw new IllegalArgumentException("Invalid maxvalue");
    }
    this.xPos = xPos;
    this.yPos = yPos;
    this.r = r;
    this.g = g;
    this.b = b;
    this.maxValue = maxValue;
  }

  /**
   * method toString overrides the built-in function for readability.
   *
   * @return the RGB values as a string.
   */
  @Override
  public String toString() {
    return this.r + " " + this.g + " " + this.b;
  }

  /**
   * returns the r value of the pixel.
   *
   * @return r value of the pixel.
   */
  @Override
  public int getR() {
    return r;
  }

  /**
   * returns the g value of the pixel.
   *
   * @return g value of the pixel.
   */
  @Override
  public int getG() {
    return g;
  }

  /**
   * returns the b value of the pixel.
   *
   * @return b value of the pixel.
   */
  @Override
  public int getB() {
    return b;
  }

  /**
   * returns the color max value of the pixel.
   *
   * @return color max value of the pixel.
   */
  @Override
  public int getMaxValue() {
    return this.maxValue;
  }

  /**
   * returns the row value of the pixel.
   *
   * @return row value of the pixel.
   */
  @Override
  public int getRow() {
    return this.xPos;
  }

  /**
   * returns the col value of the pixel.
   *
   * @return col value of the pixel.
   */
  @Override
  public int getCol() {
    return this.yPos;
  }

  /**
   * method equals overrides the built-in method so that the contents of the pixel
   * can be checked for equality.
   *
   * @param o object comparing to
   * @return
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }

    if (!(o instanceof Pixel)) {
      return false;
    }

    Pixel p = (Pixel) o;

    return this.r == p.getR() && this.g == p.getG() && this.b == p.getB()
            && this.maxValue == p.maxValue;
  }

  /**
   * hashCode method is overridden to accurately compare Pixel objects.
   *
   * @return the hash int based on fields.
   */
  @Override
  public int hashCode() {
    return Objects.hash(xPos, yPos, r, g, b, maxValue);
  }
}
