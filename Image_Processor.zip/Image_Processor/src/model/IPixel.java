package model;

/**
 * interface IPixel represents a pixel and all of its dimensions.
 */
public interface IPixel {

  /**
   * returns the row value of the pixel.
   * @return row value of the pixel.
   */
  int getRow();

  /**
   * returns the col value of the pixel.
   * @return col value of the pixel.
   */
  int getCol();

  /**
   * returns the r value of the pixel.
   * @return r value of the pixel.
   */
  int getR();

  /**
   * returns the g value of the pixel.
   * @return g value of the pixel.
   */
  int getG();

  /**
   * returns the b value of the pixel.
   * @return b value of the pixel.
   */
  int getB();

  /**
   * returns the color max value of the pixel.
   * @return col max value of the pixel.
   */
  int getMaxValue();
}
