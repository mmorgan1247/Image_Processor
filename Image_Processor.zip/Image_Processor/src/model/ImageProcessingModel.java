package model;

import java.util.Arrays;
import java.util.Objects;

/**
 * class ImageProcessingModel is an implementation of Image that
 * represents all the pixels in an image.
 */
public class ImageProcessingModel implements Image {

  private Pixel[][] map;
  private final String name;
  private final int height;
  private final int width;
  private final int maxValue;

  //SAVING AND LOADING NOT PART OF MODEL.. kind of like a view
  //test effects with small images (low pixels) check each pixel after effect
  //how to write to file - do during save function
  //command pattern for scripting

  /**
   * constructor for ImageProcessingModel that takes in a name, the dimensions
   * of the image, and the max color value.
   *
   * @param name     name of the image.
   * @param width    width of array, amount of pixels on x-axis.
   * @param height   height of array, amount of pixels on y-axis.
   * @param maxValue maximum color value.
   */
  public ImageProcessingModel(String name, int width, int height, int maxValue) {
    if (name == null) {
      throw new IllegalArgumentException("Images must have a name.");
    }
    if (width < 1 || height < 1 || maxValue < 1 || maxValue > 255) {
      throw new IllegalArgumentException("Must have positive height, width, and valid max value.");
    }
    this.name = name;
    this.width = width;
    this.height = height;
    this.maxValue = maxValue;
    this.map = new Pixel[this.width][this.height];
  }

  /**
   * method getPixelAt returns the pixel object at the given row and column.
   *
   * @param row row value of the desired pixel.
   * @param col col value of the desired pixel.
   * @return desired pixel object.
   */
  @Override
  public IPixel getPixelAt(int row, int col) {
    if (map[row][col] == null) {
      throw new IllegalArgumentException("Cannot access null pixel.");
    }
    IPixel modelPixel = this.map[row][col];
    return new Pixel(modelPixel.getRow(), modelPixel.getCol(), modelPixel.getR(), modelPixel.getG(),
            modelPixel.getB(), modelPixel.getMaxValue());
  }

  /**
   * method setPixel edits a pixel at the given row, col values
   * to have the desired RGB values.
   *
   * @param row row value of desired pixel.
   * @param col col value of desired pixel.
   * @param r   r value for desired pixel.
   * @param g   g value for desired pixel.
   * @param b   b value for desired pixel.
   */
  @Override
  public void setPixel(int row, int col, int r, int g, int b) {
    this.map[row][col] = new Pixel(row, col, r, g, b, this.maxValue);
  }

  /**
   * method getName returns the name of the Image.
   *
   * @return the name of the image.
   */
  @Override
  public String getName() {
    return this.name;
  }

  /**
   * method getWidth returns the width of the Image.
   *
   * @return the name of the Image.
   */
  @Override
  public int getWidth() {
    return this.width;
  }

  /**
   * method getHeight returns the height of the Image.
   *
   * @return the height of the Image.
   */
  @Override
  public int getHeight() {
    return this.height;
  }

  /**
   * method getMaxValue returns the maxValue of the Image.
   *
   * @return the maxValue of the Image.
   */
  @Override
  public int getMaxValue() {
    return this.maxValue;
  }

  /**
   * method equals overrides the built-in equals method to see if they
   * have the same contents and dimensions.
   *
   * @param o the object being compared to this.
   * @return if the objects are equal.
   */
  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }

    if (!(o instanceof ImageProcessingModel)) {
      return false;
    }

    ImageProcessingModel ipm = (ImageProcessingModel) o;

    if (this.maxValue == ipm.maxValue && this.height == ipm.height && this.width == ipm.width) {
      for (int i = 0; i < this.height; i += 1) {
        for (int j = 0; j < this.width; j += 1) {
          if (!this.map[j][i].equals(((ImageProcessingModel) o).map[j][i])) {
            return false;
          }
        }
      }
    }
    return true;
  }

  @Override
  public int hashCode() {
    return Objects.hash(this.maxValue, this.width, Arrays.deepHashCode(this.map), this.height);
  }
}