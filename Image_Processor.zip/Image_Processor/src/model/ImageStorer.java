package model;

import java.util.HashMap;
import java.util.Map;

/**
 * class ImageStorer is an implementation of IImageStorer
 * that contains a HashMap of all the finished images.
 */
public class ImageStorer implements IImageStorer {
  private Map<String, Image> images;

  /**
   * constructor for ImageStorer that takes no arguments and
   * initializes the images field as a new empty HashMap.
   */
  public ImageStorer() {
    this.images = new HashMap<>();
  }

  /**
   * method addImage adds an image to the HashMap images field.
   *
   * @param name  name of the image.
   * @param image the contents of the image.
   */
  @Override
  public void addImage(String name, Image image) {
    if (!this.images.containsKey(name)) {
      this.images.put(name, image);
    } else {
      throw new IllegalArgumentException("Image with this name already exists.");
    }
  }

  /**
   * returns an image from the HashMap images field, given its name.
   *
   * @param name name of the image that is being returned.
   * @return the image that corresponds to the given name.
   */
  @Override
  public Image getImage(String name) {
    if (!this.images.containsKey(name)) {
      throw new IllegalArgumentException("Image not found");
    }
    Image image = this.images.get(name);
    Image newImage = new ImageProcessingModel(image.getName(), image.getWidth(), image.getHeight(),
            image.getMaxValue());
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        newImage.setPixel(j, i, image.getPixelAt(j, i).getR(), image.getPixelAt(j, i).getG(),
                image.getPixelAt(j, i).getB());
      }
    }
    return newImage;
  }

  /**
   * clearImages method reverts the current HashMap images field
   * to a new empty HashMap.
   */
  @Override
  public void clearImages() {
    this.images = new HashMap<>();
  }

  @Override
  public Map<String, Image> getImages() {
    Map<String, Image> returnImages = new HashMap<>();

    for (Map.Entry<String, Image> e : this.images.entrySet()) {
      returnImages.put(e.getKey(), e.getValue());
    }

    return returnImages;
  }

}
