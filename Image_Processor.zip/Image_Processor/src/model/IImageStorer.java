package model;

import java.util.Map;

/**
 * interfaceIImageStorer represents a place where finished images can be stored.
 */
public interface IImageStorer {

  /**
   * method addImage adds the given Image into its collection.
   *
   * @param name  name of the image
   * @param image the image itself
   */
  void addImage(String name, Image image);

  /**
   * Method getImage seeks an image in its collection with the
   * given name and returns the Image object.
   *
   * @param name name of the target image.
   * @return the target image.
   */
  Image getImage(String name);

  /**
   * method clearImages that clears the collection of images.
   */
  void clearImages();

  /**
   * Gets the images stored in the program.
   *
   * @return the map of images
   */
  Map<String, Image> getImages();
}
