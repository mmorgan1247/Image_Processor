package model;

/**
 * interface Image that represents all the pixels in types of images.
 */
public interface Image {

  /**
   * method getPixelAt returns the pixel at the given location.
   * @param row the given row value of the desired pixel.
   * @param col the given col value of the desired pixel.
   * @return the desired pixel.
   */
  IPixel getPixelAt(int row, int col);

  /**
   * method setPixel changes the RGB values of a given pixel.
   * @param row row value of the pixel to be edited.
   * @param col col value of the pixel to be edited.
   * @param r desired r value of the pixel.
   * @param g desired g value of the pixel.
   * @param b desired b value of the pixel.
   */
  void setPixel(int row, int col, int r, int g, int b);

  /**
   * returns the name of the Image.
   * @return name of the image.
   */
  String getName();

  /**
   * returns the width of the image.
   * @return width of the image in pixels.
   */
  int getWidth();

  /**
   * returns the height of an image.
   * @return height of the image in pixels.
   */
  int getHeight();

  /**
   * returns the color max value of the image.
   * @return the color max value.
   */
  int getMaxValue();

}
