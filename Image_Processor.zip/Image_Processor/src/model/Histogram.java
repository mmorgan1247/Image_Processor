package model;

/**
 * Represents a Histogram made from an Image.
 */
public interface Histogram {

  /**
   * Gets the red values of every pixel.
   *
   * @return array containing this
   */
  int[] getRedVals();

  /**
   * Gets the green values of every pixel.
   *
   * @return array containing this
   */
  int[] getGreenVals();

  /**
   * Gets the blue values of every pixel.
   *
   * @return array containing this
   */
  int[] getBlueVals();

  /**
   * Gets the intensity values of every pixel.
   *
   * @return array containing this
   */
  int[] getIntensityVals();
}
