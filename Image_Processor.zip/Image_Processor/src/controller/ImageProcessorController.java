package controller;

import java.io.FileNotFoundException;

import model.Image;

/**
 * The controller uses inputs from the user to load in, edit, and save images.
 */
public interface ImageProcessorController {
  /**
   * Uses the controller to read user input and manipulate the model accordingly.
   */
  void control();

  /**
   * Reads a PPM file and returns an Image to be manipulated through Strategies using the
   * controller.
   * @param filename the name of the file to be read
   * @param imageName the name of the image returned
   * @return an image read from a PPM
   * @throws FileNotFoundException if the filename isn't found with the path
   */
  Image readPPM(String filename, String imageName) throws FileNotFoundException;

  public Image readImage(String fileName, String imageName);
}
