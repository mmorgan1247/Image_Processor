package controller;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Scanner;

import javax.imageio.ImageIO;
import model.IPixel;
import strategies.BlueComponent;
import strategies.Blur;
import strategies.Brighten;
import strategies.GreenComponent;
import strategies.Greyscale;
import strategies.HorizontalFlip;
import strategies.IStrategy;
import strategies.IStrategy3Args;
import strategies.Intensity;
import strategies.Luma;
import strategies.RedComponent;
import strategies.Sepia;
import strategies.Sharpen;
import strategies.Value;
import strategies.VerticalFlip;
import model.IImageStorer;
import model.Image;
import model.ImageProcessingModel;
import model.ImageStorer;
import view.IView;
import view.ImageProcessingView;

/**
 * class ControllerImpl is an implementation of ImageProcessorController
 * and represents a controller for the Image Processing user.
 */
public class ControllerImpl implements ImageProcessorController {

  protected IImageStorer model;
  private IView view;
  private final Scanner scanner;
  protected final Map<String, IStrategy> twoArgCommands;
  protected final Map<String, IStrategy3Args> threeArgCommands;

  /**
   * ControllerImpl constructor used with the GUIView.
   *
   * @param model the model to be passed to the GUIView
   */
  public ControllerImpl(IImageStorer model) {
    this.model = Objects.requireNonNull(model);
    scanner = new Scanner(new InputStreamReader(System.in));
    twoArgCommands = new HashMap<>();
    threeArgCommands = new HashMap<>();
    initializeTwoArgCommands();
    initializeCommandsThreeArgCommands();
  }

  /**
   * constructor for ControllerImpl that takes in an ImageStorer, a view and a readable.
   *
   * @param model ImageStorer that stores all the finished images.
   * @param view  view that allows the program to communicate with the user.
   * @param in    readable file for the scanner to process.
   */
  public ControllerImpl(IImageStorer model, IView view, Readable in) {
    this.model = Objects.requireNonNull(model);
    this.view = view;
    this.scanner = new Scanner(in);
    this.twoArgCommands = new HashMap<>();
    this.threeArgCommands = new HashMap<>();
    this.initializeTwoArgCommands();
    this.initializeCommandsThreeArgCommands();
  }

  /**
   * constructor for ControllerImpl that only takes in a readable. An empty
   * ImageStorer is initialized.
   *
   * @param in readable file for a scanner to process.
   */
  public ControllerImpl(Readable in) {
    this.scanner = new Scanner(in);
    this.model = new ImageStorer();
    this.twoArgCommands = new HashMap<>();
    this.threeArgCommands = new HashMap<>();
    this.initializeTwoArgCommands();
    this.initializeCommandsThreeArgCommands();
  }


  /**
   * Method readPPM returns an Image object that represents the file given by
   * the arguments.
   *
   * @param filename  the name of the file being processed.
   * @param imageName the name of the finished file.
   * @return Image representation of the file that corresponds to the argument filename.
   * @throws FileNotFoundException when the filename does not exist.
   */
  @Override
  public Image readPPM(String filename, String imageName) throws FileNotFoundException {
    Scanner sc;

    try {
      sc = new Scanner(new FileInputStream(filename));
    } catch (FileNotFoundException e) {
      throw new FileNotFoundException(e.toString());
    }
    StringBuilder builder = new StringBuilder();
    //read the file line by line, and populate a string. This will throw away any comment lines
    while (sc.hasNextLine()) {
      String s = sc.nextLine();
      if (s.charAt(0) != '#') {
        builder.append(s + System.lineSeparator());
      }
    }

    //now set up the scanner to read from the string we just built
    sc = new Scanner(builder.toString());

    String token;

    token = sc.next();
    if (!token.equals("P3")) {
      System.out.println("Invalid PPM file: plain RAW file should begin with P3");
    }

    int width = sc.nextInt();
    int height = sc.nextInt();
    int maxValue = sc.nextInt();
    Image image = new ImageProcessingModel(imageName, width, height, maxValue);
    for (int i = 0; i < height; i++) {
      for (int j = 0; j < width; j++) {
        int r = sc.nextInt();
        int g = sc.nextInt();
        int b = sc.nextInt();
        image.setPixel(j, i, r, g, b);
      }
    }
    try {
      this.model.addImage(imageName, image);
    } catch (Exception iOException) {
      System.out.println();
    }
    return image;
  }

  /**
   * Reads in any Image type and creates an Image.
   *
   * @param fileName  the name of the file to read in
   * @param imageName the name of the image in the model
   * @return an Image read from a file
   */
  public Image readImage(String fileName, String imageName) {
    BufferedImage image;
    //READ IMAGE
    try {
      image = ImageIO.read(new File(fileName));
    } catch (IOException e) {
      throw new IllegalArgumentException("File could not be read!");
    }
    //CONVERT READ IMAGE TO OUR IMAGE OBJECT
    if (image != null) {
      int width = image.getWidth();
      int height = image.getHeight();

      Image outImage = new ImageProcessingModel(imageName, width, height, 255);

      for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
          Color c = new Color(image.getRGB(j, i));
          outImage.setPixel(j, i, c.getRed(), c.getGreen(), c.getBlue());
        }
      }
      this.model.addImage(imageName, outImage);
      return outImage;
    } else {
      throw new IllegalArgumentException("Image not found.");
    }
  }

  /**
   * method control takes in no arguments and reads the input given by the user to decide
   * what parts of the code will be called on.
   */
  @Override
  public void control() {
    while (scanner.hasNext()) {
      String in = scanner.next();

      if (in.equalsIgnoreCase("quit") || in.equalsIgnoreCase("q")) {
        return;
      } else if (this.twoArgCommands.containsKey(in)) {
        checkNextArg();
        String firstArg = scanner.next();
        checkNextArg();
        String secondArg = scanner.next();
        handleTwoInputs(in, firstArg, secondArg);
      } else if (this.threeArgCommands.containsKey(in)) {
        checkNextArg();
        String firstArg3 = scanner.next();
        checkNextArg();
        String secondArg3 = scanner.next();
        checkNextArg();
        String thirdArg3 = scanner.next();
        handleThreeInputs(in, firstArg3, secondArg3, thirdArg3);
      } else {
        throw new IllegalArgumentException("Invalid command.");
      }
    }
  }


  /**
   * helper method for control that ensures there are 2 and only 2 arguments
   * after the command.
   */
  private void checkNextArg() {
    if (!scanner.hasNext()) {
      throw new IllegalArgumentException();
    }
  }

  /**
   * Handles two input Strategies with two arguments.
   */
  protected void handleTwoInputs(String command, String firstArg, String secondArg) {
    if (command.equals("load")) {
      if (getExtension(firstArg).equals("ppm")) {
        try {
          this.readPPM(firstArg, secondArg);
          System.out.println("Successfully loaded image: " + secondArg);
        } catch (FileNotFoundException e) {
          throw new IllegalArgumentException("File not found!" + firstArg);
        }
      } else {
        this.readImage(firstArg, secondArg);
        System.out.println("Successfully loaded image: " + secondArg);
      }
    } else if (command.equals("save")) {
      if (getExtension(firstArg).equals("ppm")) {
        File file = new File(firstArg);
        try {
          FileOutputStream fos = new FileOutputStream(file);
          PrintStream ps = new PrintStream(fos);
          System.setOut(ps);
          this.view = new ImageProcessingView(this.model.getImage(secondArg), System.out);
          System.out.println(this.view.makePPM());
        } catch (FileNotFoundException e) {
          throw new IllegalArgumentException("File doesn't exist!" + firstArg);
        }
      } else {
        this.saveImage(firstArg, secondArg);
      }
    } else {
      Image newImage = this.twoArgCommands.get(command).
              adjustImage(this.model.getImage(firstArg), secondArg);
      this.model.addImage(secondArg, newImage);
    }
  }


  /**
   * Handles three argument Strategy3args.
   */
  protected void handleThreeInputs(String command, String firstArg, String secondArg,
                                   String thirdArg) {
    Image newImage = this.threeArgCommands.get(command).adjustImage(firstArg,
            model.getImage(secondArg), thirdArg);
    this.model.addImage(thirdArg, newImage);
  }

  /**
   * Fills the map with the name of two arg commands and their corresponding Strategies.
   */
  private void initializeTwoArgCommands() {
    this.twoArgCommands.put("load", null);
    this.twoArgCommands.put("save", null);
    this.twoArgCommands.put("vertical-flip", new VerticalFlip());
    this.twoArgCommands.put("horizontal-flip", new HorizontalFlip());
    this.twoArgCommands.put("luma", new Luma());
    this.twoArgCommands.put("intensity", new Intensity());
    this.twoArgCommands.put("value", new Value());
    this.twoArgCommands.put("red-component", new RedComponent());
    this.twoArgCommands.put("blue-component", new BlueComponent());
    this.twoArgCommands.put("green-component", new GreenComponent());
    this.twoArgCommands.put("blur", new Blur());
    this.twoArgCommands.put("sharpen", new Sharpen());
    this.twoArgCommands.put("sepia", new Sepia());
    this.twoArgCommands.put("greyscale", new Greyscale());
  }

  /**
   * Fills the map with the name of three arg commands and their corresponding Strategies.
   */
  private void initializeCommandsThreeArgCommands() {
    this.threeArgCommands.put("brighten", new Brighten());
  }

  /**
   * Gets the file type of a file.
   *
   * @param fileName the name of the file
   * @return the extension of the file
   */
  protected String getExtension(String fileName) {
    String extension = "";
    for (int i = 0; i < fileName.length(); i++) {
      if (fileName.charAt(i) == '.') {
        extension = fileName.substring(i + 1);
      }
    }
    return extension;
  }

  /**
   * Gets the rbgint color value needed to set a pixel in BufferedImage from a Color.
   *
   * @param c the color
   * @return an int representing a rgb value
   */
  protected int getRGBColorValue(Color c) {
    int redVal = c.getRed();
    int greenVal = c.getGreen();
    int blueVal = c.getBlue();

    redVal = (redVal << 16) & 0x00FF0000;
    greenVal = (greenVal << 8) & 0x0000FF00;
    blueVal = blueVal & 0x000000FF;

    return 0xFF000000 | redVal | greenVal | blueVal;
  }

  /**
   * Helper that writes a bufferedimage to a file.
   *
   * @param firstArg  the file location
   * @param secondArg the image to be saved
   */
  protected void saveImage(String firstArg, String secondArg) {
    File file = new File(firstArg);
    //implement save for non ppm files
    Image imageSaved = this.model.getImage(secondArg);
    BufferedImage image = new BufferedImage(imageSaved.getWidth(), imageSaved.getHeight(),
            BufferedImage.TYPE_INT_ARGB);
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        IPixel pixel = imageSaved.getPixelAt(j, i);
        image.setRGB(j, i, getRGBColorValue(new Color(pixel.getR(), pixel.getG(), pixel.getB())));
      }
    }
    try {
      ImageIO.write(image, getExtension(firstArg), file);
      System.out.println("Image saved: " + secondArg);
    } catch (IOException e) {
      throw new IllegalArgumentException("File type invalid.");
    }
  }


}
