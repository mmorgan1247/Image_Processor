package controller;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.util.Objects;
import model.Histogram;
import model.HistogramImpl;
import model.IImageStorer;
import model.IPixel;
import model.Image;
import view.GUIView;
import view.IGUIView;

/**
 * Represents the controller for the GUI. It serves as an ActionListener for a Swing GUI.
 * It extends ControllerImpl for useful methods to generate images and perform filters on the model.
 */
public class GUIController extends ControllerImpl implements ImageProcessorController,
        ActionListener {
  private final IGUIView view;
  private String imageName;
  private boolean canLoadImage;
  private boolean canFilter;
  private String nameAfterFilter;

  /**
   * Creates a GUIController with a model. This controller serves as an ActionListener.
   *
   * @param model the model to be used by the controller.
   */
  public GUIController(IImageStorer model) {
    super(Objects.requireNonNull(model));
    this.view = new GUIView();
    this.imageName = "";
    this.nameAfterFilter = "";
    this.canLoadImage = false;
    this.canFilter = false;
    view.setListener(this);
  }

  @Override
  public void control() {
    view.launch();
  }


  @Override
  public void actionPerformed(ActionEvent e) {
    switch (e.getActionCommand()) {
      case "submitImageName":
        canLoadImage = true;
        imageName = view.getLoadedImageName();
        break;
      case "Open file":
        if (canLoadImage) {
          view.displayImage();
          String filePath = view.getFile();
          readImage(filePath, imageName);
          this.addAllHistograms(imageName);
          view.displayHistograms();
        } else {
          view.makePopup("You must name your image before loading it in.");
        }
        break;
      case "submitFilteredImageName":
        canFilter = true;
        this.nameAfterFilter = view.getFilteredImageName();
        break;
      case "commence":
        if (canFilter && canLoadImage) {
          String filterName = view.getSelectedFromComboBox();
          if (filterName.equals("brighten")) {
            try {
              handleThreeInputs("brighten", view.getBrightenedAmount(), imageName,
                      nameAfterFilter);
            } catch (Exception exception) {
              view.makePopup("If you want to brighten you must enter an int in the field.");
            }
          } else {
            try {
              handleTwoInputs(filterName, imageName, nameAfterFilter);
            } catch (Exception exception) {
              view.makePopup("Name after filter must be different than original.");
            }
          }
          sendImageToView(nameAfterFilter);
          addAllHistograms(nameAfterFilter);
          imageName = nameAfterFilter;
          view.setImageName(imageName);
        } else {
          view.makePopup("You must name the image after it is filtered.");
        }
        break;
      case ("save"):
        if (!imageName.equals("")) {
          view.saveImage();
          String filePath = view.getFile();
          handleTwoInputs("save", filePath, imageName);
        } else {
          view.makePopup("Must have loaded an image to save an image.");
        }
        break;
      default:
        view.makePopup("Invalid action event.");
    }
  }

  private void sendImageToView(String imageName) {
    Image imageSaved = this.model.getImage(imageName);
    BufferedImage image = new BufferedImage(imageSaved.getWidth(), imageSaved.getHeight(),
            BufferedImage.TYPE_INT_ARGB);
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        IPixel pixel = imageSaved.getPixelAt(j, i);
        image.setRGB(j, i, getRGBColorValue(new Color(pixel.getR(), pixel.getG(), pixel.getB())));
      }
    }
    view.showImage(image);
  }

  /**
   * Adds a histogram to the view by building it by each bar obtained from the model histogram.
   *
   * @param imageName the name of the image to be made a histogram from
   * @param type      the type of histogram
   */
  private void addHistogram(String imageName, String type) {
    Image image = this.model.getImage(imageName);
    Histogram histogram = new HistogramImpl(image);

    switch (type) {
      case "red":
        for (int i = 0; i < histogram.getRedVals().length; i++) {
          view.buildHistogram(i, 10, 2, histogram.getRedVals()[i], type);
        }
        break;
      case "green":
        for (int i = 0; i < histogram.getGreenVals().length; i++) {
          view.buildHistogram(i, 10, 2, histogram.getGreenVals()[i], type);
        }
        break;
      case "blue":
        for (int i = 0; i < histogram.getBlueVals().length; i++) {
          view.buildHistogram(i, 10, 2, histogram.getBlueVals()[i], type);
        }
        break;
      case "intensity":
        for (int i = 0; i < histogram.getIntensityVals().length; i++) {
          view.buildHistogram(i, 10, 2, histogram.getIntensityVals()[i], type);
        }
        break;
      default:
        break;
    }

    for (int i = 0; i < histogram.getBlueVals().length; i++) {
      view.buildHistogram(i, 10, 2, histogram.getBlueVals()[i], type);
    }
  }

  /**
   * Adds all histogram types to the view. One for each kind required.
   *
   * @param imageName the name of the image the histogram is made from
   */
  private void addAllHistograms(String imageName) {
    this.addHistogram(imageName, "red");
    this.addHistogram(imageName, "blue");
    this.addHistogram(imageName, "green");
    this.addHistogram(imageName, "intensity");
  }

}
