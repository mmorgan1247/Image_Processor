import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.io.FileNotFoundException;

import controller.ControllerImpl;
import controller.GUIController;
import controller.ImageProcessorController;
import model.ImageStorer;

/**
 * This class runs a script, takes input from text, or runs a GUI depending on CLI.
 */
public class Main {

  /**
   * Use the controller to control user input.
   */
  public static void main(String[] args) {

    ImageProcessorController controller;
    Readable in = new InputStreamReader(System.in);
    if (args.length == 2) {
      if (args[0].equals("-file")) {
        try {
          File input = new File(args[1]);
          controller = new ControllerImpl(new FileReader(input));
          controller.control();
        } catch (FileNotFoundException e) {
          System.out.print("File not found, try again.");
        }
      }
    } else if (args.length == 1) {
      if (args[0].equals("-text")) {
        controller = new ControllerImpl(in);
        controller.control();
      }
    } else {
      controller = new GUIController(new ImageStorer());
      controller.control();
    }
  }
}




