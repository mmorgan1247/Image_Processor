package view;

import java.io.IOException;

/**
 * class Utils represent utils for the image processing program.
 */
public class Utils {
  /**
   * method write takes in a message and writes it to the given appendable.
   *
   * @param message message to be outputted.
   * @param ap      appendable for
   */
  public static void write(String message, Appendable ap) {
    try {
      ap.append(message);
    } catch (IOException e) {
      e.printStackTrace();
    }
  }
}
