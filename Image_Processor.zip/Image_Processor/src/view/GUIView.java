package view;

import java.awt.GridBagConstraints;
import java.awt.FlowLayout;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.Objects;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JComboBox;
import javax.swing.JTextField;
import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;

/**
 * Represents the GUI for the Image Processor implemented in the Swing library.
 * Contains panels and other JComponents that make up the GUI.
 */
public class GUIView extends JFrame implements IGUIView {
  private JPanel panel;
  private JButton fileOpenButton;
  private GridBagConstraints c;
  private JFileChooser fChooser;
  private JComboBox<String> combobox;
  private JTextField loadImageTextField;
  private JTextField afterFilterTextField;
  private JButton submitFilteredImageName;
  private JButton submitImageName;
  private JLabel imageLabel;
  private JButton doFilter;
  private JButton saveButton;
  private JTextField brightenField;
  private HistogramPanel redHistogram;
  private HistogramPanel greenHistogram;
  private HistogramPanel blueHistogram;
  private HistogramPanel intensityHistogram;

  /**
   * Constructs a GUIView, adding all the necessary components and setting action commands.
   */
  public GUIView() {
    super();
    panel = new JPanel();
    this.panel.setSize(new Dimension(500, 500));
    this.panel.setLayout(new GridBagLayout());
    c = new GridBagConstraints();

    JScrollPane scrollPane = new JScrollPane(panel);
    redHistogram = new HistogramPanel();
    blueHistogram = new HistogramPanel();
    greenHistogram = new HistogramPanel();
    intensityHistogram = new HistogramPanel();

    saveButton = new JButton("Save");
    saveButton.setActionCommand("save");

    add(scrollPane);
    setSize(new Dimension(800, 800));

    panel.setBackground(Color.WHITE);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 0;
    c.gridy = 0;
    panel.add(saveButton, c);

    JPanel dialogBoxesPanel = new JPanel();
    dialogBoxesPanel.setBorder(BorderFactory.createTitledBorder("Dialog boxes"));
    dialogBoxesPanel.setLayout(new BoxLayout(dialogBoxesPanel, BoxLayout.PAGE_AXIS));
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 1;
    c.gridy = 0;
    panel.add(dialogBoxesPanel, c);

    JPanel fileopenPanel = new JPanel();
    fileopenPanel.setLayout(new FlowLayout());
    dialogBoxesPanel.add(fileopenPanel);
    fileOpenButton = new JButton("Open a file");
    fileOpenButton.setActionCommand("Open file");
    fileopenPanel.add(fileOpenButton);

    loadImageTextField = new JTextField("Enter the name of the image you want to load in");
    submitImageName = new JButton("Submit");
    submitImageName.setActionCommand("submitImageName");
    JPanel namePanel = new JPanel();
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 0;
    c.gridy = 0;
    namePanel.add(loadImageTextField, c);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 1;
    c.gridy = 0;
    namePanel.add(submitImageName, c);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 0;
    c.gridy = 2;
    panel.add(namePanel, c);

    afterFilterTextField = new JTextField("Enter the name of the image after being filtered");
    submitFilteredImageName = new JButton("Submit");
    submitFilteredImageName.setActionCommand("submitFilteredImageName");
    JPanel filterPanel = new JPanel();
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 0;
    c.gridy = 0;
    filterPanel.add(afterFilterTextField, c);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 1;
    c.gridy = 0;
    filterPanel.add(submitFilteredImageName, c);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 1;
    c.gridy = 2;

    JPanel comboboxPanel = new JPanel();
    comboboxPanel.setBorder(BorderFactory.createTitledBorder("Combo boxes"));
    comboboxPanel.setLayout(new BoxLayout(comboboxPanel, BoxLayout.PAGE_AXIS));
    comboboxPanel.add(filterPanel);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 1;
    c.gridy = 1;
    panel.add(comboboxPanel, c);

    comboboxPanel.add(filterPanel);

    JLabel comboboxDisplay = new JLabel("Select filter");
    comboboxPanel.add(comboboxDisplay);
    String[] options = {"brighten", "blur", "greyscale", "sharpen", "horizontal-flip",
        "vertical-flip", "luma", "intensity", "value", "sepia", "sharpen", "blue-component",
        "red-component", "green-component"};
    combobox = new JComboBox<>();
    //the event listener when an option is selected
    combobox.setActionCommand("Filter");

    for (int i = 0; i < options.length; i++) {
      combobox.addItem(options[i]);
    }
    comboboxPanel.add(combobox);

    doFilter = new JButton("Filter");
    doFilter.setActionCommand("commence");
    comboboxPanel.add(doFilter);

    brightenField = new JTextField("Replace with amount to brighten");
    comboboxPanel.add(brightenField);

  }

  @Override
  public String makePPM() {
    return null;
  }

  @Override
  public void setListener(ActionListener listener) {
    fileOpenButton.addActionListener(listener);
    combobox.addActionListener(listener);
    submitImageName.addActionListener(listener);
    submitFilteredImageName.addActionListener(listener);
    doFilter.addActionListener(listener);
    saveButton.addActionListener(listener);
  }


  @Override
  public void launch() {
    this.setVisible(true);
  }

  @Override
  public String getFile() {
    Objects.requireNonNull(fChooser);
    return fChooser.getSelectedFile().getAbsolutePath();
  }

  @Override
  public String getLoadedImageName() {
    return this.loadImageTextField.getText();
  }

  @Override
  public String getFilteredImageName() {
    return afterFilterTextField.getText();
  }

  @Override
  public String getBrightenedAmount() {
    return brightenField.getText();
  }

  @Override
  public void makePopup(String message) {
    JOptionPane.showMessageDialog(this, message);
  }

  @Override
  public String getSelectedFromComboBox() {
    return Objects.requireNonNull(this.combobox.getSelectedItem()).toString();
  }

  @Override
  public void showImage(BufferedImage image) {
    ImageIcon img = new ImageIcon(image);
    imageLabel.setIcon(img);
    pack();
  }

  @Override
  public void saveImage() {
    fChooser = new JFileChooser(".");
    int retvalue = fChooser.showSaveDialog(this);
    if (retvalue == JFileChooser.APPROVE_OPTION) {
      File f = fChooser.getSelectedFile();
    }
  }

  @Override
  public void setImageName(String name) {
    loadImageTextField.setText(name);
  }

  @Override
  public void buildHistogram(int x, int y, int w, int h, String type) {
    switch (type) {
      case "red":
        this.redHistogram.addBar(x, y, w, h);
        break;
      case "blue":
        this.blueHistogram.addBar(x, y, w, h);
        break;
      case "green":
        this.greenHistogram.addBar(x, y, w, h);
        break;
      case "intensity":
        this.intensityHistogram.addBar(x, y, w, h);
        break;
      default:
        break;
    }
  }

  @Override
  public void displayHistograms() {
    JPanel histogramPanel = new JPanel();
    histogramPanel.setSize(new Dimension(200, 200));
    histogramPanel.add(redHistogram);
    histogramPanel.add(greenHistogram);
    histogramPanel.add(blueHistogram);
    histogramPanel.add(intensityHistogram);
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 0;
    c.gridy = 3;
    panel.add(histogramPanel, c);
    pack();
  }

  @Override
  public void displayImage() {

    fChooser = new JFileChooser(".");
    FileNameExtensionFilter filter = new FileNameExtensionFilter(
            "Accepted Image Types", "jpg", "gif", "ppm", "png");
    fChooser.setFileFilter(filter);
    int retvalue = fChooser.showOpenDialog(this);
    if (retvalue == JFileChooser.APPROVE_OPTION) {
      File f = fChooser.getSelectedFile();
    }

    File f = fChooser.getSelectedFile();
    ImageIcon image = new ImageIcon(f.getAbsolutePath());
    imageLabel = new JLabel(image);
    imageLabel.setSize(new Dimension(500, 500));
    JScrollPane scrollPane = new JScrollPane(imageLabel);
    scrollPane.setPreferredSize(new Dimension(500, 500));
    c.fill = GridBagConstraints.HORIZONTAL;
    c.gridx = 0;
    c.gridy = 1;
    panel.add(scrollPane, c);
    pack();
  }

}

