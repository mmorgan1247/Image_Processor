package view;

/**
 * Represents methods for an IHistogramPanel, a way of representing Histograms visually.
 */
public interface IHistogramPanel {
  /**
   * Adds a bar of the histogram in the form of a Rectangle.
   *
   * @param x the x location
   * @param y y location
   * @param w width
   * @param h height
   */
  void addBar(int x, int y, int w, int h);
}
