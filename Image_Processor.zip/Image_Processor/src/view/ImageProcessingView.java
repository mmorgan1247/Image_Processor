package view;

import model.Image;

/**
 * Class ImageProcessingView is an implementation of IView that represents
 * a view of an Image that is in PPM format.
 */
public class ImageProcessingView implements IView {

  private final Image model;
  private final Appendable appendable;

  /**
   * constructor for ImageProcessingView.
   *
   * @param model      the image being processed.
   * @param appendable the output path.
   */
  public ImageProcessingView(Image model, Appendable appendable) {
    if (model == null) {
      throw new IllegalArgumentException("Cannot have null model.");
    }
    this.model = model;
    this.appendable = appendable;
  }

  /**
   * makePPM method creates a PPM file and writes it to the appendable.
   *
   * @return a String of a PPM file
   */
  @Override
  public String makePPM() {

    Utils.write("P3\n", this.appendable);
    Utils.write(model.getWidth() + " " + model.getHeight() + "\n", this.appendable);
    Utils.write("255\n", this.appendable);

    for (int i = 0; i < model.getHeight(); i++) {
      for (int j = 0; j < model.getWidth(); j++) {
        Utils.write(model.getPixelAt(j, i).toString() + " ", this.appendable);
      }
      Utils.write("\n", this.appendable);
    }
    return this.appendable.toString();
  }

}
