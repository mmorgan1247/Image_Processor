package view;

import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;

/**
 * Methods for GUIView. Many of which are used by the controller to affect the view as an
 * ActionListener.
 */
public interface IGUIView extends IView {

  /**
   * Displays an image on a Panel.
   */
  void displayImage();

  /**
   * Sets the view visible.
   */
  void launch();

  /**
   * Gets the file path when loading in a file.
   *
   * @return the path of the file
   */
  String getFile();

  /**
   * Displays all four histograms for each image.
   */
  void displayHistograms();

  /**
   * Gets the name of the loaded image that is set by the user.
   *
   * @return the name of the loaded image
   */
  String getLoadedImageName();

  /**
   * Gets the name of the image to be filtered. Must be different from the loaded image.
   *
   * @return the name of the image filtered
   */
  String getFilteredImageName();

  /**
   * Gets the interval the image is being brightened.
   *
   * @return a String that can be converted to an int
   */
  String getBrightenedAmount();

  /**
   * Creates a pop-up with the passed message.
   *
   * @param message the message to appear
   */
  void makePopup(String message);

  /**
   * Gets which item was selected from the combobox.
   *
   * @return the item selected from the combobox
   */
  String getSelectedFromComboBox();

  /**
   * Shows a new image received from the controller after a filter.
   *
   * @param image the image received from the controller after a filter
   */
  void showImage(BufferedImage image);

  /**
   * Opens a save dialog to save an image.
   */
  void saveImage();

  /**
   * Sets the name of the image currently viewed.
   *
   * @param name the name of the image viewed
   */
  void setImageName(String name);

  /**
   * Adds a bar to one of the histograms in the GUI.
   *
   * @param x    x of the rect
   * @param y    y of the rect
   * @param w    width of the rect
   * @param h    height of the rect
   * @param type the type of histogram
   */
  void buildHistogram(int x, int y, int w, int h, String type);

  /**
   * Sets a listener to a JComponent. Used with the controller mainly.
   *
   * @param listener the listener to be set
   */
  void setListener(ActionListener listener);

}
