package view;

import java.awt.Rectangle;
import java.awt.Dimension;
import java.awt.Color;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JPanel;

/**
 * Represents a JPanel containing rectangles that form a histogram.
 */
public class HistogramPanel extends JPanel implements IHistogramPanel {
  private final List<Rectangle> rectList;

  /**
   * Constructs a HistogramPanel with default size and an empty List of Rectangle.
   */
  public HistogramPanel() {
    super();
    setSize(new Dimension(100, 100));
    setBackground(Color.BLACK);
    this.rectList = new ArrayList<>();
  }

  @Override
  public void paintComponent(Graphics g) {
    super.paintComponent(g);

    for (Rectangle r : rectList) {
      g.fillRect((int) r.getX(), (int) r.getY(), (int) r.getWidth(), (int) r.getHeight());
      g.setColor(Color.RED);
    }
  }

  @Override
  public void addBar(int x, int y, int w, int h) {
    this.rectList.add(new Rectangle(x, y, w, h));
  }


}
