package view;

/**
 * interface IView represents views for Images as PPM text files.
 */
public interface IView {

  /**
   * method makePPM will write an image to a PPM file and output it.
   *
   * @return a text file ppm
   */
  String makePPM();

}
