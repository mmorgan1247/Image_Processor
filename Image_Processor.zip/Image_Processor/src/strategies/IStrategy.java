package strategies;

import model.Image;

/**
 * interface IStrategy represents different ways that an image can be altered.
 */
public interface IStrategy {
  //method returned from function object

  /**
   * method adjustImage adjusts the image according to the directions of its
   * implementation.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return the new image.
   */
  Image adjustImage(Image image, String name);

}
