package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class verticalFlip represents an implementation of IStrategy that flips an image vertically.
 */
public class VerticalFlip implements IStrategy {
  //function object makes a new image and chaining these function objects allows multiple
  //filters to be applied

  /**
   * method adjustImage flips a given image horizontally and returns it.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return a vertically flipped image
   */
  @Override
  public Image adjustImage(Image image, String name) {
    Image newImage = new ImageProcessingModel(name, image.getWidth(), image.getHeight(),
            image.getMaxValue());
    int midHeight = image.getHeight() / 2;
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        if (i < midHeight) {
          int delta = midHeight - i;
          newImage.setPixel(j, i - 1 + (2 * delta), image.getPixelAt(j, i).getR(),
                  image.getPixelAt(j, i).getG(), image.getPixelAt(j, i).getB());
        } else if (i > midHeight) {
          int delta = i - midHeight;
          newImage.setPixel(j, i - 1 - (2 * delta), image.getPixelAt(j, i).getR(),
                  image.getPixelAt(j, i).getG(), image.getPixelAt(j, i).getB());
        } else {
          if (image.getHeight() % 2 == 1) {
            newImage.setPixel(j, i, image.getPixelAt(j, i).getR(), image.getPixelAt(j, i).getG(),
                    image.getPixelAt(j, i).getB());
          } else {
            newImage.setPixel(j, i - 1, image.getPixelAt(j, i).getR(),
                    image.getPixelAt(j, i).getG(), image.getPixelAt(j, i).getB());
          }
        }
      }
    }
    return newImage;
  }
}

