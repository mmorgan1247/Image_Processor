package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class Value represents an implementation of IStrategy
 * that turns an image grey by maxing all color values.
 */
public class Value implements IStrategy {
  /**
   * method adjustImage turns the image a shade of grey by turning the all color value
   * components to the max.
   *
   * @param image image being altered.
   * @param name  name of the new image.
   * @return the new image.
   */
  public Image adjustImage(Image image, String name) {
    Image destImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getHeight(); i += 1) {
      for (int j = 0; j < image.getWidth(); j += 1) {
        destImage.setPixel(j, i, image.getMaxValue(),
                image.getMaxValue(), image.getMaxValue());
      }
    }
    return destImage;
  }
}
