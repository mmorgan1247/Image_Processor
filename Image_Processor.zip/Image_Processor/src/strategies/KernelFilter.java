package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * abstract class KernelFilter contains a method adjustImage that uses a kernel to
 * apply a filter to an image.
 */
abstract public class KernelFilter {

  protected Image image;
  protected double[][] matrix;

  /**
   * applies a filter to an image.
   *
   * @param image the image being filtered.
   * @param name  the name of the new image.
   * @return the new image.
   */
  public Image adjustImage(Image image, String name) {
    this.image = image;
    Image newImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getWidth(); i += 1) {
      for (int j = 0; j < image.getHeight(); j += 1) {
        int[] rgbVals = this.getVals(i, j);
        //checks if any of the rgb values are greater than the color maxValue
        for (int maxChecker = 0; maxChecker < rgbVals.length; maxChecker += 1) {
          if (rgbVals[maxChecker] > image.getMaxValue()) {
            rgbVals[maxChecker] = image.getMaxValue();
          }
          if (rgbVals[maxChecker] < 0) {
            rgbVals[maxChecker] = 0;
          }
        }
        newImage.setPixel(i, j, rgbVals[0], rgbVals[1], rgbVals[2]);
      }
    }
    return newImage;
  }


  /**
   * helper method that returns a 1D array of the RGB values of a given pixel after
   * being filtered.
   *
   * @param iImage position of pixel.
   * @param jImage position of pixel.
   * @return RGB values of transformed pixel.
   */

  private int[] getVals(int iImage, int jImage) {
    int[] vals = new int[3];
    for (int rgb = 0; rgb < 3; rgb += 1) {
      //gets the matrix that will mirror the kernel for the given RGB place
      int[][] redTargs = frameMatrix(iImage, jImage, rgb);
      for (int iMatrix = 0; iMatrix < matrix.length; iMatrix += 1) {
        for (int jMatrix = 0; jMatrix < matrix.length; jMatrix += 1) {
          vals[rgb] += (int) Math.round(redTargs[iMatrix][jMatrix] * matrix[iMatrix][jMatrix]);
        }
      }
    }
    return vals;
  }

  /**
   * returns a 2D array of R G or B values that mirror the kernel.
   * @param iPos 'i' position of the middle pixel.
   * @param jPos j position of the middle pixel.
   * @param rgb  0 = R, 1 = G, 2 = B.
   * @return the mirror.
   */
  private int[][] frameMatrix(int iPos, int jPos, int rgb) {
    int[][] toReturn = new int[matrix.length][matrix.length];
    for (int i = 0; i < matrix.length; i += 1) {
      for (int j = 0; j < matrix.length; j += 1) {
        if (rgb == 0) {
          try {
            toReturn[i][j] = image.getPixelAt(iPos - (matrix.length / 2) + i,
                    jPos - (matrix.length / 2) + j).getR();
          } catch (Exception arrayIndexOutOfBoundsException) {
            toReturn[i][j] = 0;
          }
        } else if (rgb == 1) {
          try {
            toReturn[i][j] = image.getPixelAt(iPos - (matrix.length / 2) + i,
                    jPos - (matrix.length / 2) + j).getG();
          } catch (Exception arrayIndexOutOfBoundsException) {
            toReturn[i][j] = 0;
          }
        } else if (rgb == 2) {
          try {
            toReturn[i][j] = image.getPixelAt(iPos - (matrix.length / 2) + i,
                    jPos - (matrix.length / 2) + j).getB();
          } catch (Exception arrayIndexOutOfBoundsException) {
            toReturn[i][j] = 0;
          }
        }
      }
    }
    return toReturn;
  }
}
