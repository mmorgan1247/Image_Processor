package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class Luma represents an implementation of IStrategy that
 * turns an image grey using the luma formula.
 */
public class Luma implements IStrategy {

  /**
   * alters given image into greyscale by using the luma formula.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return the new image.
   */
  public Image adjustImage(Image image, String name) {
    Image destImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getHeight(); i += 1) {
      for (int j = 0; j < image.getWidth(); j += 1) {
        double lumaAvg = image.getPixelAt(j, i).getR() * 0.2126 +
                image.getPixelAt(j, i).getG() * 0.7152 +
                image.getPixelAt(j, i).getB() * 0.0722;
        int avgRounded = (int) Math.round(lumaAvg);

        destImage.setPixel(j, i, avgRounded, avgRounded, avgRounded);
      }
    }
    return destImage;
  }
}
