package strategies;

import model.IPixel;
import model.Image;
import model.ImageProcessingModel;


/**
 * Class brighten represents an implementation of IStrategy that alters an image's color.
 */
public class Brighten implements IStrategy3Args {
  /**
   * Method adjustImage brightens or darkens an image, depending on the increment value.
   *
   * @param increment the amount of which an image is to be brightened or darkened.
   * @param original  the original image.
   * @param destName  the name of the new image.
   * @return the new image.
   */
  @Override
  public Image adjustImage(String increment, Image original, String destName) {
    Image dest = new ImageProcessingModel(destName, original.getWidth(), original.getHeight(),
            original.getMaxValue());
    int inc = Integer.parseInt(increment);
    for (int i = 0; i < original.getHeight(); i += 1) {
      for (int j = 0; j < original.getWidth(); j += 1) {
        IPixel currPixel = original.getPixelAt(j, i);
        //ensure no pixels r, g, or b goes over maxvalue
        int r = currPixel.getR() + inc;
        r = compareToMaxValue(r, original.getMaxValue());
        r = compareToZero(r);
        int g = currPixel.getG() + inc;
        g = compareToMaxValue(g, original.getMaxValue());
        g = compareToZero(g);
        int b = currPixel.getB() + inc;
        b = compareToMaxValue(b, original.getMaxValue());
        b = compareToZero(b);
        dest.setPixel(j, i, r, g, b);
      }
    }
    return dest;
  }

  /**
   * helper method compareToZero checks if the color value is below zero.
   *
   * @param color the value of the color.
   * @return If it is below zero, the value is returned as zero. If not, it doesn't change.
   */
  private int compareToZero(int color) {
    if (color < 0) {
      return 0;
    }
    return color;
  }

  /**
   * helper method compareToMaxValue checks if the color value is over maxValue.
   *
   * @param color the value of the color.
   * @return If it is above maxColor, the value is returned as maxColor.
   *         If not, it is returned as it came.
   */
  private int compareToMaxValue(int color, int max) {
    if (color > max) {
      return max;
    }
    return color;
  }


}
