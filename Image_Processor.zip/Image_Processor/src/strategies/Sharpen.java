package strategies;

/**
 * class Sharpen represents an implementation of IStrategy that
 * sharpens an image using a kernel.
 */
public class Sharpen extends KernelFilter implements IStrategy {

  /**
   * constructor for Sharpen that instantiates a kernel through a 2D array of doubles.
   */
  public Sharpen() {
    this.matrix = new double[][]{{-0.125, -0.125, -0.125, -0.125, -0.125},
      {-0.125, 0.25, 0.25, 0.25, -0.125},
      {-0.125, 0.25, 1, 0.25, -0.125},
      {-0.125, 0.25, 0.25, 0.25, -0.125},
      {-0.125, -0.125, -0.125, -0.125, -0.125}};
  }

}
