package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * abstract class ColorTransformation contains a method adjustImage that applies a
 * color transformation by using a kernel.
 */
abstract public class ColorTransformation extends KernelFilter {
  protected Image image;
  protected double[][] matrix;

  /**
   * applies a color transformation to an image.
   *
   * @param image the image to be transformed.
   * @param name  the name of the new image.
   * @return the new image object.
   */
  public Image adjustImage(Image image, String name) {
    this.image = image;
    Image newImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getWidth(); i += 1) {
      for (int j = 0; j < image.getHeight(); j += 1) {
        int[] rgbVals = this.getVals(i, j);
        //checks if any of the rgb values are greater than the color maxValue
        for (int maxChecker = 0; maxChecker < rgbVals.length; maxChecker += 1) {
          if (rgbVals[maxChecker] > image.getMaxValue()) {
            rgbVals[maxChecker] = image.getMaxValue();
          }
          if (rgbVals[maxChecker] < 0) {
            rgbVals[maxChecker] = 0;
          }
        }
        newImage.setPixel(i, j, rgbVals[0], rgbVals[1], rgbVals[2]);
      }
    }
    return newImage;
  }

  /**
   * helper method for adjustImage that returns the RGB values in a 1D array
   * of a given pixel location.
   *
   * @param iImage i value of the given pixel location.
   * @param jImage j value of the given pixel location.
   * @return an array containing the rgb values of the new image pixel.
   */
  protected int[] getVals(int iImage, int jImage) {
    int[] vals = new int[3];
    int rVal = this.image.getPixelAt(iImage, jImage).getR();
    int gVal = this.image.getPixelAt(iImage, jImage).getG();
    int bVal = this.image.getPixelAt(iImage, jImage).getB();

    for (int rgb = 0; rgb < 3; rgb += 1) {
      vals[rgb] += Math.round(this.matrix[rgb][0] * rVal);
      vals[rgb] += Math.round(this.matrix[rgb][1] * gVal);
      vals[rgb] += Math.round(this.matrix[rgb][2] * bVal);
    }
    return vals;
  }
}
