package strategies;

/**
 * class Greyscale represents an implementation of IStrategy that
 * turns an image greyscale using a kernel.
 */
public class Greyscale extends ColorTransformation implements IStrategy {

  /**
   * constructor for Greyscale that instantiates a kernel through a 2D array of doubles.
   */
  public Greyscale() {
    this.matrix = new double[][]{
      {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722},
      {0.2126, 0.7152, 0.0722}};
  }
}
