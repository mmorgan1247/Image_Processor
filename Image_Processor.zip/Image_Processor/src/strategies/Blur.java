package strategies;

/**
 * class Blur represents an implementation of IStrategy that
 * blurs an image using a kernel.
 */
public class Blur extends KernelFilter implements IStrategy {

  /**
   * constructor for Blur that instantiates a kernel through a 2D array of doubles.
   */
  public Blur() {
    this.matrix = new double[][]{{.0625, .125, .0625}, {.125, .25, .125}, {.0625, .125, .0625}};
  }

}
