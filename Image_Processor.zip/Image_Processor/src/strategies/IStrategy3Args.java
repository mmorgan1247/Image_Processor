package strategies;

import model.Image;

/**
 * interface IStrategy3Args represents a strategy that requires 3 arguments for its
 * adjustImage method.
 */
public interface IStrategy3Args {

  /**
   * adjusts the image to what the implementation requires.
   *
   * @param inc      number that corresponds to the degree an image is being altered.
   * @param original the image being altered.
   * @param destName name of the new image.
   * @return the new image.
   */
  Image adjustImage(String inc, Image original, String destName);
}
