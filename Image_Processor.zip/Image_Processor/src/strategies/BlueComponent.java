package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class BlueComponent represents an implementation of IStrategy that
 * turns an image grey using its blue component.
 */
public class BlueComponent implements IStrategy {

  /**
   * method adjustImage turns the image a shade of grey by turning the blue
   * component to zero.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return the new image.
   */
  public Image adjustImage(Image image, String name) {
    Image destImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getHeight(); i += 1) {
      for (int j = 0; j < image.getWidth(); j += 1) {
        destImage.setPixel(j, i, image.getPixelAt(j, i).getR(),
                image.getPixelAt(j, i).getG(), 0);
      }
    }
    return destImage;
  }
}
