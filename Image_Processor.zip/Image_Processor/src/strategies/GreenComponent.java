package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class GreenComponent represents an implementation of IStrategy
 * that turns an image grey using its green component.
 */
public class GreenComponent implements IStrategy {

  /**
   * method adjustImage turns the image a shade of grey by turning the green
   * component to zero.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return the new image.
   */
  public Image adjustImage(Image image, String name) {
    Image destImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getHeight(); i += 1) {
      for (int j = 0; j < image.getWidth(); j += 1) {
        destImage.setPixel(j, i, image.getPixelAt(j, i).getR(),
                0, image.getPixelAt(j, i).getB());
      }
    }
    return destImage;
  }
}
