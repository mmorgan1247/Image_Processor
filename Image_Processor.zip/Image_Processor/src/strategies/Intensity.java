package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class Intensity represents an implementation of IStrategy that
 * turns an image grey using the average of the RGB values.
 */
public class Intensity implements IStrategy {

  /**
   * method adjustImage converts the given image to grey using the average
   * of the 3 color values.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return the new image.
   */
  public Image adjustImage(Image image, String name) {
    Image destImage = new ImageProcessingModel(name, image.getWidth(),
            image.getHeight(), image.getMaxValue());
    for (int i = 0; i < image.getHeight(); i += 1) {
      for (int j = 0; j < image.getWidth(); j += 1) {
        double localAvg = (image.getPixelAt(j, i).getG() +
                image.getPixelAt(j, i).getR() + image.getPixelAt(j, i).getB()) / 3.0;
        //avg is rounded to an int so that it may be passed to the pixel array
        int avg = (int) Math.round(localAvg);
        destImage.setPixel(j, i, avg, avg, avg);
      }
    }
    return destImage;
  }
}
