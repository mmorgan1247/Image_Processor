package strategies;

import model.Image;
import model.ImageProcessingModel;

/**
 * class HorizontalFlip represents an implementation of IStrategy that flips an image
 * horizontally.
 */
public class HorizontalFlip implements IStrategy {
  /**
   * method adjustImage flips the image horizontally and returns a new image.
   *
   * @param image the image being altered.
   * @param name  name of the new image being created.
   * @return a horizontally flipped image
   */
  @Override
  public Image adjustImage(Image image, String name) {
    Image newImage = new ImageProcessingModel(name, image.getWidth(), image.getHeight(),
            image.getMaxValue());
    int midWidth = image.getWidth() / 2;
    for (int i = 0; i < image.getHeight(); i++) {
      for (int j = 0; j < image.getWidth(); j++) {
        if (j < midWidth) {
          int delta = midWidth - j;
          newImage.setPixel(j - 1 + (2 * delta), i, image.getPixelAt(j, i).getR(),
                  image.getPixelAt(j, i).getG(), image.getPixelAt(j, i).getB());
        } else if (j > midWidth) {
          int delta = j - midWidth;
          newImage.setPixel(j - 1 - (2 * delta), i, image.getPixelAt(j, i).getR(),
                  image.getPixelAt(j, i).getG(), image.getPixelAt(j, i).getB());
        } else {
          if (image.getWidth() % 2 == 1) {
            newImage.setPixel(j, i, image.getPixelAt(j, i).getR(), image.getPixelAt(j, i).getG(),
                    image.getPixelAt(j, i).getB());
          } else {
            newImage.setPixel(j - 1, i, image.getPixelAt(j, i).getR(),
                    image.getPixelAt(j, i).getG(), image.getPixelAt(j, i).getB());
          }
        }
      }
    }
    return newImage;
  }
}
