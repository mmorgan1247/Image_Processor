# Image_Processor
This Image Processor program contains the capabilities to apply various edits to an image. It takes in arguments through a command line to direct the function of the program. 

When commands are given, they are take in by the Main class. The controller ControllerImpl is given the commands and checks what the first command is, which should be the name of the specific function that the user wants to perform. If the program is directed to load an image, it will check the file type and add an image to an ImageStorer. If the program is directed to save an image, it will output the file to the system. Any other command will call a function object to carry out its specific function.

changes made to the design for assignment 5: there were no enormous design changes, as we felt we were well prepared to implement the functions for this assignment. Our model's getPixel was changed to return an IPixel to account for other image types. Helper methods getRGBColorValue and getExtension were added to the controller for the same reason. 

Changes for Assignment 6: We made the GUIController extend the ControllerImpl because it made sense to use many of the methods from there to parse inputs and apply filters. The GUI is generally finished except the histograms displaying. The code for the histograms seems sound but we ran out of time to fully implement them.


Image smallPic.ppm is our own. 


INTERFACE: ImageProcessorController represents controllers for Image Processors.
Class: ControllerImpl is an implementation of the ImageProcessorController: this class processes input and calls on the model to do as the command wishes.
INTERFACE: IImageStorer represents objects that store finished images.
Class: ImageStorer is an implementation of the IImageStorer: this class contains a HashMap that stores Images and is able to edit and return various data from the collection of images.
INTERFACE: Image represents image objects.
Class: ImageProcessingModel is an implementation of the Image: this class contains capabilities to edit data in an image.
INTERFACE: IPixel represents pixel objects.
Class: Pixel is an implementation of IPixel that contains data within a Pixel, such as its color values and position.
INTERFACE: IStrategy represents various methods of editing an Image, specifically those that take in 2 parameters after the command.
INTERFACE: IStrategy3Args represents various methods of editing an Image, specifically those that take in 3 parameters after the command.
Class: RedComponent is a function object that implements IStrategy that converts an image to greyscale by editing its red component.
Class: GreenComponent is a function object that implements IStrategy that converts an image to greyscale by editing its green component.
Class: BlueComponent is a function object that implements IStrategy that converts an image to greyscale by editing its blue component.
Class: Value is a function object that implements IStrategy that converts an image to greyscale by maxing color values of each pixel.
Class: Luma is a function object that implements IStrategy that converts an image to greyscale by using the luma algorithm.
Class: Intensity is a function object that implements IStrategy that converts an image to greyscale by editing each pixel color value to the average of its individual RGB values.
Class: HorizontalFlip is a function object that implements IStrategy that flips an image horizontally.
Class: VerticalFlip is a function object that implements IStrategy that flips an image vertically.
Class: Brighten is a function object that implements IStrategy3Args that changes an image's tint either lighter or darker.
INTERFACE: IView represents views for an Image Processing program.
Class: ImageProcessingView is an implementation of IView that communicates with the user.
Class: Utils contains the capiabilities for a program to write out to the user.
Class: Main takes in arguments from the user.
ABSTRACT CLASS: ColorTransformation contains the capability to apply a color transformation using a kernel.
ABSTRACT CLASS: KernelFilter contains the capability to apply a filter using a kernel.
Class: Blur is an implementation of IStrategy and extension of KernelFilter that blurs a given image using a kernel.
Class: Sharpen is an implementation of IStrategy and extension of KernelFilter that sharpens a given image using a kernel.
Class: Sepia is an implementation of IStrategy and extension of ColorTransformation that applies sepiatone using a kernel.
Class: Greyscale is an implementation of IStrategy and extension of ColorTransformation that applies greyscale using a kernel.

TESTCLASS: ImageProcessingControllerTest tests abilities of the ImageProcessingController class.
TESTCLASS: CompoundedStrategiesTest tests abilities of the IStrategy and IStrategy3Args classes.
TESTCLASS: ImageProcessingModelTest tests abilities of the ImageProcessingModel class.
TESTCLASS: ImageStorerTest tests abilities of the ImageStorer class.
TESTCLASS: MockImageStorer aids the ImageProcessingController test in testing the ImageProcessingController.
TESTCLASS: ImageProcessingViewTest tests abilities of the ImageProcessingView class.

CITATION FOR BOSTON IMAGE: https://www.bostonusa.com/plan/boston-neighborhoods/waterfront/
